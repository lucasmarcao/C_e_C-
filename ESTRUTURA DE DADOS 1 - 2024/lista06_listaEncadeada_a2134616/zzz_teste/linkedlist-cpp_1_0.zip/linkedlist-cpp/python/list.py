



def main():
    list = []
    
    for i in range(50):
        list.append(i*2)

    print(list)

main()