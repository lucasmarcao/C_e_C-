#include <cstdio>
#include "vectorlist.h"
#include "linkedlist.h"

int main() {
    VectorList* vlist = new VectorList;

    for (int i = 0; i < 10; i++) {
        vlist->push_back(i*2);
        vlist->print();
    }

    LinkedList* llist = new LinkedList;

    for (int i = 0; i < 10; i++) {
        llist->push_front(i*2);
        llist->print();
    }

    delete vlist;
    delete llist;

    return 0;
}